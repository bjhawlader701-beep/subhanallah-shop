# Subhanallah Shop Android App
নতুন Android Studio starter project।
Customer login ছাড়া shopping, Cart + Direct Buy Now, Order Tracking, আলাদা Admin Panel, Product/Order/Settings/Admin roles এবং Supabase backend-এর জন্য structure রাখা হয়েছে।
এটি starter project; production Supabase connection পরের ধাপে যোগ করতে হবে।