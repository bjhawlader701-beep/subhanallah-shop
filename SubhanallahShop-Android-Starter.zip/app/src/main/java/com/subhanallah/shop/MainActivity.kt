package com.subhanallah.shop
import android.app.AlertDialog
import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity
class MainActivity : AppCompatActivity() {
 override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); setContentView(R.layout.activity_main)
  findViewById<Button>(R.id.productsBtn).setOnClickListener { show("Products","Products, categories, images, prices এবং Buy Now এখানে থাকবে।") }
  findViewById<Button>(R.id.cartBtn).setOnClickListener { show("Cart","Add to Cart system এখানে থাকবে।") }
  findViewById<Button>(R.id.orderBtn).setOnClickListener { show("Direct Order","Customer login ছাড়াই নাম, ফোন ও ঠিকানা দিয়ে order করা যাবে।") }
  findViewById<Button>(R.id.trackBtn).setOnClickListener { show("Track Order","Order ID + phone দিয়ে নিজের order tracking করা যাবে।") }
  findViewById<Button>(R.id.adminBtn).setOnClickListener { show("Admin Login","Secure Admin Login-এর পর Products, Orders, Admin roles ও Settings পরিচালনা করা যাবে।") }
 }
 private fun show(t:String,m:String){ AlertDialog.Builder(this).setTitle(t).setMessage(m).setPositiveButton("OK",null).show() }
}