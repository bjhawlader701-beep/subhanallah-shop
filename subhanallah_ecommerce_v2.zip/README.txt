সুবহানাল্লাহ E-Commerce V2
Customer: index.html
Admin: admin/index.html
Demo password: 1234

এটি frontend prototype। বাস্তব production-এর জন্য secure backend authentication, database, image storage, order system, payment gateway এবং push notifications প্রয়োজন।
